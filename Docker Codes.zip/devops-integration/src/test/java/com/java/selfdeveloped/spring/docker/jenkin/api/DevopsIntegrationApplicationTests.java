package com.java.selfdeveloped.spring.docker.jenkin.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevopsIntegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
