package com.java.selfdeveloped.spring.docker.jenkin.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockerJenkinIntegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DockerJenkinIntegrationApplication.class, args);
	}

}
