package com.java.selfdeveloped.spring.docker.compose.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMongoDockerComposeApplicationTests {

	@Test
	void contextLoads() {
	}

}
